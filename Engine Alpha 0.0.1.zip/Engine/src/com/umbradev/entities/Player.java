package com.umbradev.entities;

import java.awt.image.BufferedImage;

public class Player extends Entity {

	public Player(int x, int y, int width, int height, BufferedImage sprite) {
		super(x, y, width, height, sprite);
		
	}

}
